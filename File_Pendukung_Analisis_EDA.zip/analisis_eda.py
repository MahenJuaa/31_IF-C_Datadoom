"""Analisis Data Understanding - Water Potability (Datadoom). Jalankan: python analisis_eda.py <path_csv> <dir_output>"""
import sys, json, pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
csv = sys.argv[1] if len(sys.argv)>1 else 'water_potability.csv'
out = sys.argv[2] if len(sys.argv)>2 else '.'
import os; os.makedirs(out+'/fig',exist_ok=True)
df = pd.read_csv(csv); F=[c for c in df.columns if c!='Potability']
sns.set_theme(style='whitegrid', font_scale=0.9); R={}
R['shape']=list(df.shape); R['dup']=int(df.duplicated().sum())
R['dtypes']={c:str(t) for c,t in df.dtypes.items()}
R['na']={c:int(df[c].isna().sum()) for c in df.columns}
R['na_pct']={c:round(float(df[c].isna().mean()*100),2) for c in df.columns}
R['rows_any_na']=int(df.isna().any(axis=1).sum()); R['complete_rows']=int((~df.isna().any(axis=1)).sum())
d=df.describe().T; d['skew']=df.skew(); R['desc']=d.round(3).reset_index().to_dict('records')
vc=df.Potability.value_counts(); R['cls']={int(k):int(v) for k,v in vc.items()}
R['imb_ratio']=round(vc[0]/vc[1],3)
# outliers IQR
O={}
for c in F:
    x=df[c].dropna(); q1,q3=x.quantile([.25,.75]); i=q3-q1; lo,hi=q1-1.5*i,q3+1.5*i
    n=int(((x<lo)|(x>hi)).sum()); O[c]=dict(lo=round(lo,3),hi=round(hi,3),n=n,pct=round(n/len(x)*100,2),
      zn=int((np.abs(stats.zscore(x))>3).sum()))
R['outl']=O
# corr
cm=df.corr(); R['corr_target']=cm['Potability'].drop('Potability').round(4).to_dict()
fc=cm.loc[F,F].where(~np.eye(len(F),dtype=bool)); R['max_abs_corr']=float(fc.abs().max().max())
a=fc.abs().stack().sort_values(ascending=False); R['top_pairs']=[(i,j,round(float(cm.loc[i,j]),4)) for (i,j),v in a.iloc[:6:2].items()]
# tests
T={}
for c in F:
    a0=df.loc[df.Potability==0,c].dropna(); a1=df.loc[df.Potability==1,c].dropna()
    u,p=stats.mannwhitneyu(a0,a1); T[c]=dict(m0=round(a0.mean(),3),m1=round(a1.mean(),3),md0=round(a0.median(),3),md1=round(a1.median(),3),p=float(p))
R['tests']=T
# missing vs target
M={}
for c in ['ph','Sulfate','Trihalomethanes']:
    g=df.groupby(df[c].isna())['Potability'].mean(); M[c]=dict(pot_miss=round(float(g.get(True,np.nan))*100,2),pot_obs=round(float(g.get(False,np.nan))*100,2))
    ct=pd.crosstab(df[c].isna(),df.Potability); M[c]['chi2_p']=float(stats.chi2_contingency(ct)[1])
R['miss_vs_target']=M
R['domain_flags']={'ph_lt6.5':int((df.ph<6.5).sum()),'ph_gt8.5':int((df.ph>8.5).sum()),'ph_min':float(df.ph.min()),'ph_max':float(df.ph.max()),
 'turb_gt5':int((df.Turbidity>5).sum()),'zero_or_neg':{c:int((df[c]<=0).sum()) for c in F}}
json.dump(R,open(out+'/hasil_analisis.json','w'),indent=1,default=float)
# figures
fig,ax=plt.subplots(figsize=(5,3.4)); b=ax.bar(['0 (Tidak layak)','1 (Layak)'],[vc[0],vc[1]],color=['#c0504d','#4f81bd'])
for r,v in zip(b,[vc[0],vc[1]]): ax.text(r.get_x()+r.get_width()/2,v+20,f'{v} ({v/len(df)*100:.1f}%)',ha='center')
ax.set_ylabel('Jumlah sampel'); ax.set_ylim(0,2300); plt.tight_layout(); plt.savefig(out+'/fig/f1_kelas.png',dpi=200); plt.close()
na=df[F].isna().sum(); na=na[na>0]
fig,ax=plt.subplots(figsize=(5.5,3.2)); b=ax.barh(na.index,na.values,color='#e69f00')
for r,v in zip(b,na.values): ax.text(v+10,r.get_y()+r.get_height()/2,f'{v} ({v/len(df)*100:.2f}%)',va='center')
ax.set_xlim(0,1000); ax.set_xlabel('Jumlah nilai kosong'); plt.tight_layout(); plt.savefig(out+'/fig/f2_missing.png',dpi=200); plt.close()
fig,axs=plt.subplots(3,3,figsize=(9,7.5))
for ax,c in zip(axs.ravel(),F): sns.histplot(df[c].dropna(),bins=35,kde=True,ax=ax,color='#4f81bd'); ax.set_xlabel(c); ax.set_ylabel('Frekuensi')
plt.tight_layout(); plt.savefig(out+'/fig/f3_histogram.png',dpi=200); plt.close()
fig,axs=plt.subplots(3,3,figsize=(9,7.5))
for ax,c in zip(axs.ravel(),F): sns.boxplot(data=df,x='Potability',y=c,ax=ax,hue='Potability',palette=['#c0504d','#4f81bd'],legend=False,fliersize=2); ax.set_xlabel('Potability')
plt.tight_layout(); plt.savefig(out+'/fig/f4_boxplot_target.png',dpi=200); plt.close()
fig,ax=plt.subplots(figsize=(7,5.6)); sns.heatmap(cm,annot=True,fmt='.2f',cmap='RdBu_r',center=0,vmin=-1,vmax=1,ax=ax,square=True,cbar_kws={'shrink':.8})
plt.tight_layout(); plt.savefig(out+'/fig/f5_korelasi.png',dpi=200); plt.close()
ct=pd.Series(R['corr_target']).sort_values()
fig,ax=plt.subplots(figsize=(5.5,3.6)); ax.barh(ct.index,ct.values,color=['#c0504d' if v<0 else '#4f81bd' for v in ct.values]); ax.set_xlabel('Korelasi Pearson dengan Potability'); ax.set_xlim(-.1,.1)
plt.tight_layout(); plt.savefig(out+'/fig/f6_korelasi_target.png',dpi=200); plt.close()
print('ok')
